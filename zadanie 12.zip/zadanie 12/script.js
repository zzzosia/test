import { format } from "https://cdn.jsdelivr.net/npm/date-fns@2.30.0/+esm";
import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm";

const SUPABASE_URL = 'https://eohovqvrwlupfctqzhdk.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVvaG92cXZyd2x1cGZjdHF6aGRrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc2NzUxMjcsImV4cCI6MjA2MzI1MTEyN30.lvHieYaC0EiorhK-HWaD57AZq_cg7Ui7pKQ1yvuvxQI';

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
const TABLE = 'article';

const articlesDiv = document.getElementById('articles');
const form = document.getElementById('articleForm');
const sortSelect = document.getElementById('sortSelect');

async function fetchArticles(order = 'created_at.desc') {
  const [column, direction] = order.split('.');
  const { data, error } = await supabase
    .from(TABLE)
    .select('*')
    .order(column, { ascending: direction === 'asc' });

  if (error) {
    console.error('Błąd pobierania:', error);
    articlesDiv.innerHTML = '<p>Błąd wczytywania artykułów.</p>';
    return;
  }

  articlesDiv.innerHTML = '';
  data.forEach(article => {
    const div = document.createElement('article');
    div.innerHTML = `
      <h3>${article.title}</h3>
      <h4>${article.subtitle}</h4>
      <p><strong>${article.author}</strong> | ${format(new Date(article.created_at), 'dd-MM-yyyy')}</p>
      <p>${article.content}</p>
      <p><em>Tagi: ${article.tags || 'brak'}</em></p>
      <p>Status: ${article.is_published ? 'Opublikowany' : 'Szkic'}</p>
    `;
    articlesDiv.appendChild(div);
  });
}

form.addEventListener('submit', async e => {
  e.preventDefault();
  const formData = new FormData(form);
  const values = Object.fromEntries(formData.entries());

  values.is_published = values.is_published === 'on'; // checkbox
  values.created_at = new Date(values.created_at).toISOString(); // date input
  values.tags = values.tags || null;

  const { error } = await supabase.from(TABLE).insert([values]);
  if (error) {
    alert('Błąd dodawania artykułu');
    console.error(error);
  } else {
    form.reset();
    fetchArticles(sortSelect.value);
  }
});

sortSelect.addEventListener('change', () => {
  fetchArticles(sortSelect.value);
});

fetchArticles();
